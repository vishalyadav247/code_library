ACDiscountApp.PDPage.DisplayTiers = function () {
  var storeTime = globalFields.Storetime();
  // Parse the date string into individual components
   let [currentYear, currentMonth, currentDay, currentHours, currentMinutes, currentSeconds] = storeTime.split(/[\sT:-]/);
   currentYear = parseInt(currentYear);
   currentMonth = parseInt(currentMonth); // Months are zero-based in JavaScript
   currentDay = parseInt(currentDay);
   currentHours = parseInt(currentHours);
   currentMinutes =parseInt(currentMinutes);
   currentSeconds = parseInt(currentSeconds);

    function makeTimer(end_date) {
      if(globalFields.isProduct_Page){
        if(end_date != null){
        jQuery("#ac_countDown").css("display", "block");
          var endTime =  end_date;
        // Increment seconds by 1
         currentSeconds++;
        
        // Adjust minutes, hours, and day if necessary
        if (currentSeconds >= 60) {
            currentSeconds = 0;
            currentMinutes++;
            if (currentMinutes >= 60) {
                currentMinutes = 0;
                currentHours++;
                if (currentHours >= 24) {
                    currentHours = 0;
                    currentDay++;
                }
            }
        }
        
            // Reformat the updated timestamp
            let currentStoreTime = `${currentYear}-${currentMonth.toString().padStart(2, '0')}-${currentDay.toString().padStart(2, '0')}T${currentHours.toString().padStart(2, '0')}:${currentMinutes.toString().padStart(2, '0')}:${currentSeconds.toString().padStart(2, '0')}`;
            endTime = (Date.parse(endTime) / 1000);
            var now = currentStoreTime;
            now = (Date.parse(now) / 1000);
          
            var timeLeft = endTime - now;
            var days = Math.floor(timeLeft / 86400); 
            var hours = Math.floor(timeLeft / 3600);
            var exactHour = hours % 24;
            var minutes = Math.floor((timeLeft - (hours * 3600 )) / 60);
            var seconds = Math.floor((timeLeft - (hours * 3600) - (minutes * 60)));
            var isDays = false;
            if (days > 0 || hours > 24){isDays = true;}
            if (days < 0) { days = "00"; /*hours = "0"; minutes = "0"; seconds = "0";*/ }
            if (hours < 10) { hours = "0" + hours; }
            if (minutes < 10) { minutes = "0" + minutes; }
            if (seconds < 10) { seconds = "0" + seconds; }
            if(timeLeft > 0){
              if(isDays){
                $(".ac__days").html(days); $(".ac__hours").html(exactHour); $(".ac__minutes").html(minutes);
                $(".ac_sec, .ac__colon.seconds").hide();
              }
              else{
                $(".ac__hours").html(exactHour); $(".ac__minutes").html(minutes); $(".ac__seconds").html(seconds);		
                $(".ac_day, .ac__colon.hours").hide(); $(".ac_sec, .ac__colon.seconds").show();
              }
            }
            else{jQuery('.ac__settings__table, #ac_countDown').remove();}
          
          setTimeout(function () {
            jQuery('.ac__settings__table').after(jQuery("#ac_countDown"));
          }, 500);
        }
      }
  }   


    var hide_buttons = null;
    var HideAdditionalPayments = function() {      
      hide_buttons = setInterval(function() {
       
        if(jQuery('.shopify-payment-button__button').length>0){
          jQuery('.shopify-payment-button__button').hide();
          clearInterval(hide_buttons);
        }
      }, 500);
    }
  
    this.DisplayTiersFn = function () {
        setTimeout(function () {
            jQuery('.ac__settings__table').remove();
            var selectedVariant = jQuery('input[name^=id]:checked, select[name^=id], input[name=id], hidden[name^=id]', jQuery('form[action="/cart/add"]')).val();
            if (selectedVariant != null && globalFieldsProductPage_AC.productMetafield != '[]' && globalFieldsProductPage_AC.productMetafield != undefined) {
                var tierObj = globalFields.GetTierObject(globalFieldsProductPage_AC.productMetafield, selectedVariant);
                if (tierObj != undefined && tierObj.status && globalFields.StartEndDateValid(tierObj.start_date, tierObj.end_date)) {
                var getDates = globalFields.TimerStartEndDateValid(tierObj.start_date, tierObj.end_date);
                getDates.valid; getDates.start_date; getDates.end_date;
                let timer_settings = parsed_timer_settings;                
                WriteTableHeading(tierObj);
                WriteTableRows(tierObj, selectedVariant);
                if(timer_settings != undefined){                
                  if(timer_settings.TimerStatus){  
                    if(getDates.valid){
                        setInterval(function() { makeTimer(getDates.end_date); }, 1000);
                    }
                  }
            	}
                  jQuery('.shopify-payment-button__button').hide();
                  setTimeout(function(){
                    jQuery('.shopify-payment-button__button').hide();
                	HideAdditionalPayments();
                  }, 2000);
                  setTimeout(function(){
                    clearInterval(hide_buttons);
                  }, 5000);
                }
            }
        }, 200);
    }
    
    setTimeout(function(){
      clearInterval(hide_buttons);
    }, 10000);

    this.OnVariantChange = function () {
        setTimeout(function () {
            $(".single-option-selector,.single-option-selector__radio").change(function () {
                displayTiers.DisplayTiersFn();
            });
        }, 2000);
    }
    
    this.changePrice = function(){
      	var productPrice = jQuery('form[action="/cart/add"] .price-list .money').text().split('£')[1];
      	productPrice = globalFields.formatMoney(Number(productPrice).toFixed(2), globalFields.amount);
// 	  	alert(productPrice);
      if(jQuery('table.ac__settings__table').length > 0){
        var discountedPrice = jQuery('table.ac__settings__table .ac__tr:last td:eq(1) .money').text().split('£')[1];
        discountedPrice = globalFields.formatMoney(Number(discountedPrice).toFixed(2), globalFields.amount);
        
        
        var discountedQty = jQuery('table.ac__settings__table .ac__tr:last td:eq(0)').text().split('+')[0];
        discountedQty = Number(discountedQty);
        var originalChangeQty = jQuery('form[action="/cart/add"] input.quantity-selector__value').val();
        originalChangeQty = Number(originalChangeQty);
        if(isNaN(originalChangeQty)){
        	originalChangeQty = 1;
        }
//         console.log('discountedQty', discountedQty);
//         console.log('originalChangeQty', originalChangeQty);
//         alert(originalChangeQty);
        
        var updatedItemPrice = 0
        var selectedVariant = jQuery('input[name^=id]:checked, select[name^=id], input[name=id], hidden[name^=id]', jQuery('form[action="/cart/add"]')).val();
        if(selectedVariant == ""){ 
          let id_= Object.keys(globalFieldsProductPage_AC.variantsPriceArray_PD)
          selectedVariant = id_[0];
        }
        if (selectedVariant != null && globalFieldsProductPage_AC.productMetafield != '[]' && globalFieldsProductPage_AC.productMetafield != undefined && selectedVariant != "") {
          var tierObj = globalFields.GetTierObject(globalFieldsProductPage_AC.productMetafield, selectedVariant);
          if (tierObj != undefined && tierObj.status && globalFields.StartEndDateValid(tierObj.start_date, tierObj.end_date)) {
            
            for (i = 0; i < tierObj.tier_min.length; i++) {
              var tierPrice = parseFloat(tierObj.tier_values[i]);
              var minTier = parseInt(tierObj.tier_min[i]), maxTier = tierObj.tier_max[i] != 'max' ? parseInt(tierObj.tier_max[i]) : tierObj.tier_max[i];
              var updatedLinePrice = 0, condition1 = false, condition2 = false;
              var originalPrice_ = jQuery('form[action="/cart/add"] .price-list .money').text().split('£')[1];
				originalPrice_ = Number(originalPrice_);
              
              condition1 = originalChangeQty >= minTier;
              condition2 = maxTier == "max" || originalChangeQty <= maxTier;
              
              if (condition1 && condition2) { break; }
            }
            
            if (condition1 && condition2) {
                if (tierObj.discount_type == 'percentage') {
                    var originalPriceCut = parseFloat(globalFields.ConvertToFixedDecimalNumber((parseFloat(tierPrice) / 100) * globalFields.ConvertToFixedDecimalNumber(originalPrice_)));
                    updatedItemPrice = globalFields.ConvertToFixedDecimalNumber(globalFields.ConvertToFixedDecimalNumber(originalPrice_) - originalPriceCut);
                }
                else if (tierObj.discount_type == 'fixed') {
                    updatedItemPrice = globalFields.ConvertToFixedDecimalNumber(globalFields.ConvertToFixedDecimalNumber(originalPrice_) - parseFloat(tierPrice));
                }
                else if (tierObj.discount_type == 'fixed_price') {
                    updatedItemPrice = globalFields.ConvertToFixedDecimalNumber(parseFloat(tierPrice));
                }
              
              updatedItemPrice = globalFields.formatMoney(Number(updatedItemPrice).toFixed(2), globalFields.amount);
              jQuery('form[action="/cart/add"] .price-list').html(`
              <div class="price-list"><span class="price">
              <span class="hidePrice"><span class="money" style="text-decoration-line: line-through;">${productPrice}</span>
              <span class="money">${updatedItemPrice}</span>
              </span></span></div>`);
            }
            else{
              jQuery('form[action="/cart/add"] .price-list').html(`
              <div class="price-list"><span class="price">
              <span class="hidePrice"><span class="money">${productPrice}</span>
              </span></span></div>`);
              }
          }
        }
        
      }
    }
    
    this.OnQuantityChange = function () {
        setTimeout(function () {
            $("input.quantity-selector__value").keyup(function(){
                displayTiers.changePrice();
            });
            $('form[action="/cart/add"] button.quantity-selector__button').click(function(){
              setTimeout(function(){  
              	displayTiers.changePrice();
              },100);
            });
        }, 2000);
    }
  
    var TableHeadHtml = function (contentHtml, tableSelector, position) {
        jQuery(tableSelector).before(contentHtml)
    }

    var WriteTableHeading = function (tierObj) {
      
      var tableSelector = 'form[action="/cart/add"] .product-form__buttons button[name="add"]';
        if (globalFields.settings.selected_table == "table1") {
            TableHeadHtml('<table class="ac__settings__table ac_table1" id="ac_table1"><tbody class="ac__tbody"><tr class="ac__tr ac__tr1"><th class="ac__th ac__th1">' + globalFields.settings.table_headers.header1_value + '</th><th class="ac__th ac__th2">' + globalFields.settings.table_headers.header2_value + '</th></tr></tbody></table>', tableSelector);
        }
        if (globalFields.settings.selected_table == "table2") {

            TableHeadHtml('<table class="ac__settings__table ac_table2" id="ac_table2"><tbody class="ac__tbody"><tr class="ac__tr ac__tr1"><th class="ac__th ac__th1">' + globalFields.settings.table_headers.header1_value + '</th><th class="ac__th ac__th2">' + globalFields.settings.table_headers.header2_value + '</th><th class="ac__th ac__th3">' + globalFields.settings.table_headers.header3_value + '</th></tr></tbody></table>', tableSelector);
        }

        if (globalFields.settings.selected_table == "table3") {
             TableHeadHtml('<table class="ac__settings__table ac_table3" id="ac_table3"><tbody class="ac__tbody"><tr class="ac__tr ac__tr1"><th class="ac__th ac__th1">' + globalFields.settings.table_headers.header1_value + '</th><th class="ac__th ac__th3">' + globalFields.settings.table_headers.header3_value + '</th></tr></tbody></table>', tableSelector);
        }

        if (globalFields.settings.selected_table == "table4") {
            TableHeadHtml('<table class="ac__settings__table ac_table4" id="ac_table4"><tbody class="ac__tbody"></tbody></table>', tableSelector);
        }
    }

    var TableRowHtml = function (contentHtml, tableSelector) {
        jQuery(tableSelector).append(contentHtml);
    }

    var TableRowSingle = function (tieredMin_, tieredMax_, discountedPrice, tieredOff, index) {
       
        var plusSign = tieredMin_ == tieredMax_ ? '' : '+', buyText = 'Buy ';
        var priceHtml = '<span class="money" data-currency-' + globalFields.currency.toLowerCase() + '="' + globalFields.currencySymbol + discountedPrice + '" data-currency="' + globalFields.currency + '">' + globalFields.formatMoney(discountedPrice, globalFields.amount) + '</span>';
        if (globalFields.settings.selected_table == "table1") {
            TableRowHtml('<tr class="ac__tr ac__tr' + (index + 1) + '"> <td class="ac__td ac__td1">' + tieredMin_ + plusSign + '</td><td class="ac__td ac__td2">' + tieredOff + '</td></tr>', '#ac_table1 .ac__tbody');
        }

        if (globalFields.settings.selected_table == "table2") {
            TableRowHtml('<tr class="ac__tr ac__tr' + (index + 1) + '"> <td class="ac__td ac__td1">' + tieredMin_ + '</td><td class="ac__td ac__td2">' + tieredMax_ + '</td><td class="ac__td ac__td3" >' + tieredOff + '</td></tr>', '#ac_table2 .ac__tbody');
        }

        if (globalFields.settings.selected_table == "table3") {
            TableRowHtml('<tr class="ac__tr ac__tr' + (index + 1) + '"> <td class="ac__td ac__td1">' + tieredMin_ + plusSign + '</td><td class="ac__td ac__td3">' + tieredOff + '</td></tr>', '#ac_table3 .ac__tbody');
        }

        if (globalFields.settings.selected_table == "table4") {
            var quantityTextTable4 = tieredMin_ + "-" + tieredMax_;
            if (tieredMax_ == "+") {
                quantityTextTable4 = tieredMin_ + "+";
            }
            TableRowHtml('<tr class="ac__tr ac__tr' + index + '"> <td class="ac__td ac__td1">' + globalFields.settings.table_body.body1_value + ' ' + tieredMin_ + ' ' + globalFields.settings.table_body.body2_value + ' ' + tieredOff + '</td></tr>', '#ac_table4');
        }
// 		jQuery('form[action="/cart/add"] .price-list').after(priceHtml);
    }

    var WriteTableRows = function (tierObj, selectedVariant_) {
        var originalPrice_ = globalFieldsProductPage_AC.variantsPriceArray_PD[selectedVariant_]; originalPrice_ = originalPrice_ / 100;
        for (i = 0; i < tierObj.tier_min.length; i++) {
            var isBreakLoop = false, tieredOff = Number(tierObj.tier_values[i]);
            var tieredMin_ = parseInt(tierObj.tier_min[i]), tieredMax_ = tierObj.tier_max[i], discountedPrice = 0;

            if (tieredMax_ != "max") {
                tieredMax_ = parseInt(tieredMax_);
            }
            else {
                tieredMax_ = "+";
            }

            if (tierObj.discount_type == "percentage") {
                discountedPrice = Number(originalPrice_.toFixed(2));
                var p = parseFloat(tieredOff) / 100, originalPriceCut_ = Number(parseFloat(p * discountedPrice).toFixed(2));
                discountedPrice = discountedPrice - originalPriceCut_;
                if (discountedPrice <= 0) {
                    discountedPrice = 0;
                    tieredOff = "100%";
                    isBreakLoop = true;
                    tieredMax_ = "+";
                }
                else {
                    discountedPrice = discountedPrice.toFixed(2);
                    tieredOff = tieredOff + "% OFF";
                }
            }
            else if (tierObj.discount_type == "fixed_price") {
                discountedPrice = tieredOff.toFixed(2);
                tieredOff = globalFields.formatMoney(tieredOff.toFixed(2), globalFields.amount);
            }
            else {
//                 discountedPrice = Number((originalPrice_ - tieredOff).toFixed(2));
//                 if (discountedPrice <= 0) {
//                     discountedPrice = 0;
//                     tieredOff = globalFields.formatMoney(originalPrice_.toFixed(2), globalFields.amount);
//                     isBreakLoop = true;
//                     tieredMax_ = "+";
//                 }
//                 else {
                    discountedPrice = discountedPrice.toFixed(2);
                    tieredOff = globalFields.formatMoney(tieredOff.toFixed(2), globalFields.amount) + " OFF";
//                 }
            } 

tieredMin_ = globalFields.formatMoney(tieredMin_.toFixed(2), globalFields.amount) ;
            TableRowSingle(tieredMin_, tieredMax_, discountedPrice, tieredOff, i + 1);

            if (isBreakLoop) { break; }
        }
    }

}

var globalFieldsProductPage_AC = new ACDiscountApp.PDPage.Global(), displayTiers = new ACDiscountApp.PDPage.DisplayTiers();
displayTiers.DisplayTiersFn(); displayTiers.OnVariantChange(); displayTiers.OnQuantityChange(); 
setTimeout(function(){
displayTiers.changePrice();
},3000);  