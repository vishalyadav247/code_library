var globalFields = {
    currency: 'GBP', // Set to GBP for your store
    currencySymbol: '£', // Set to the pound symbol
    formatMoney: function(amount) {
        // Define the formatting function if needed, or use existing one
        return this.currencySymbol + parseFloat(amount).toFixed(2);
    },
    ConvertToFixedDecimalString: function(value) {
        return parseFloat(value).toFixed(2);
    }
};

var DisplayShippingMessage = function() {
    // Assuming your updated total price is in a span with class 'totals__subtotal-value .money'
    var updatedTotalPriceElement = document.querySelector('.totals__subtotal-value .money:not(s > .money)');
    var updatedTotalPrice = updatedTotalPriceElement ? parseFloat(updatedTotalPriceElement.getAttribute('data-currency-gbp')) : 0;

    var messageDisplay = document.getElementById('messageDisplay');
    if (!messageDisplay) {
        // If the messageDisplay element doesn't exist, create it.
        messageDisplay = document.createElement('div');
        messageDisplay.id = 'messageDisplay';
        // Place the messageDisplay element wherever it is appropriate in your HTML
        document.querySelector('.cart-subtotal').appendChild(messageDisplay);
    }

    var message = "Updated Price: " + globalFields.currencySymbol + globalFields.ConvertToFixedDecimalString(updatedTotalPrice) + ". ";
    if (updatedTotalPrice < 120) {
        var extraAmountNeeded = 120 - updatedTotalPrice;
        message += "Please buy " + globalFields.currencySymbol + globalFields.ConvertToFixedDecimalString(extraAmountNeeded) + " amount more to avail shipping.";
    } else {
        message += "Hello";
    }

    messageDisplay.innerHTML = message;
};

// This function needs to be called after the UpdateCartSubtotal function has run and updated the subtotal
DisplayShippingMessage();
