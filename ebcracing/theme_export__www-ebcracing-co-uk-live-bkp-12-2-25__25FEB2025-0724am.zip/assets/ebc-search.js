document.addEventListener('DOMContentLoaded', () => {

    let serverUrl = 'https://potnvehiclefinder.co.uk'
    let pageUrl = 'https://www.ebcracing.co.uk/pages/search';

    function getQueryParam(param) {
        const urlParams = new URLSearchParams(window.location.search);
        return urlParams.get(param);
    }

    function capitalizeWords(str) {
        return str.toLowerCase().replace(/(?:^|\s)\S/g, function (a) { return a.toUpperCase(); });
    }

    let domProducts = [];
    let makeSelect = document.querySelector('#make');
    let modelSelect = document.querySelector('#model');
    let yearSelect = document.querySelector('#start_year');
    let engineTypeSelect = document.querySelector('#engine_type');
    let skuSelect = document.querySelector('#sku');
    let productInfo = document.querySelector('#appProductWrapper');
    let filterResetBtn = document.querySelector('.filterReset');
    let filterQueryData;
    let tagColors;
    let filterChips = document.querySelector('.currentFilter');

    let make = getQueryParam('make');
    let model = getQueryParam('model');
    let year = getQueryParam('year');
    let engineType = getQueryParam('engine_type');

    function updateURL() {
        const make = makeSelect.value || '';
        const model = modelSelect.value || '';
        const year = yearSelect.value || '';
        const engineType = engineTypeSelect.value || '';

        const url = new URL(window.location.href);
        url.searchParams.set('make', make);
        url.searchParams.set('year', year);
        url.searchParams.set('model', model);
        url.searchParams.set('engine_type', engineType);

        Array.from(url.searchParams.entries()).forEach(([key, value]) => {
            if (!value) url.searchParams.delete(key);
        });

        window.history.pushState({ path: url.href }, '', url.href);
    }

    function fetchMakes() {
        fetch(`${serverUrl}/api/csv-data-makes`)
            .then((response) => response.json())
            .then((csvData) => {
                csvData.sort((a, b) => a.make.localeCompare(b.make));
                csvData.forEach((product) => {
                    const option = document.createElement('option');
                    option.value = product.make;
                    option.textContent = product.make.toUpperCase();
                    makeSelect && makeSelect.appendChild(option);
                });
                if (make) {
                    makeSelect.value = make;
                    fetchYears(make, () => {
                        if (year) {
                            yearSelect.value = year;
                            fetchModels(make, year, () => {
                                if (model) {
                                    modelSelect.value = model;
                                    fetchEngineTypes(make, year, model, () => {
                                        if (engineType) {
                                            engineTypeSelect.value = engineType;
                                        }
                                    }); 
                                }
                            });
                        }
                    });
                    
                }
            })
            .catch((error) => console.error('Error fetching makes:', error));
    }

    fetchMakes();

    // Function to fetch years based on the selected model
    function fetchYears(selectedMake, callback) {
        if (!selectedMake) return;
  
        fetch(`${serverUrl}/api/csv-data-years?make=${selectedMake}`)
            .then((response) => response.json())
            .then((years) => {
                years.sort((a, b) => b.year - a.year);
                yearSelect.innerHTML = '<option value="">Select Year</option>';
                years.forEach((Year) => {
                    const option = document.createElement('option');
                    option.value = Year.year;
                    option.textContent = Year.year;
                    yearSelect.appendChild(option);
                });
                yearSelect.nextElementSibling.classList.add('hidden')
                if (callback) callback();
            })
            .catch((error) => console.error('Error fetching years:', error));
    }

      // Function to fetch models based on the selected make
    function fetchModels(selectedMake, selectedYear, callback) {
        if (!selectedYear) return;

        fetch(`${serverUrl}/api/csv-data-models?make=${selectedMake}&year=${selectedYear}`)
            .then((response) => response.json())
            .then((models) => {
                models.sort((a, b) => a.localeCompare(b));
                modelSelect.innerHTML = '<option value="">Select Model</option>';
                models.forEach((modelOption) => {
                    const option = document.createElement('option');
                    option.value = modelOption;
                    option.textContent = modelOption.toUpperCase();
                    modelSelect.appendChild(option);
                });
                modelSelect.nextElementSibling.classList.add('hidden')
                if (callback) callback();
            })
            .catch((error) => console.error('Error fetching models:', error));
    }

    // Function to fetch engine types based on the selected year
    function fetchEngineTypes(selectedMake, selectedYear, selectedModel, callback) {
        if (!selectedModel) return;
      
        fetch(`${serverUrl}/api/csv-data-engineTypes?make=${selectedMake}&year=${selectedYear}&model=${selectedModel}`)
            .then((response) => response.json())
            .then((engineTypes) => {
                engineTypeSelect.innerHTML = '<option value="">Select Engine Type</option>';
                engineTypes.forEach((engineType) => {
                    const option = document.createElement('option');
                    option.value = engineType.engineType;
                    option.textContent = capitalizeWords(engineType.engineType);
                    engineTypeSelect.appendChild(option);
                });
                engineTypeSelect.nextElementSibling.classList.add('hidden')
                if (callback) callback();
            })
            .catch((error) => console.error('Error fetching engine types:', error));
    }

    // Event listener for changes in the "Make" dropdown
    makeSelect && makeSelect.addEventListener('change', () => {
        if (productInfo) { productInfo.innerHTML = '' };
        yearSelect.value = '';
        yearSelect.nextElementSibling.classList.remove('hidden')
        modelSelect.value = '';
        engineTypeSelect.value = '';
        fetchYears(makeSelect.value);
        updateURL();
        if(productInfo){
          productInfo.classList.remove('noProductFound')
        }
    });

    // Event listener for changes in the "Year" dropdown
    yearSelect && yearSelect.addEventListener('change', () => {
        if (productInfo) { productInfo.innerHTML = '' };
        modelSelect.value = '';
        modelSelect.nextElementSibling.classList.remove('hidden')
        engineTypeSelect.value = '';
        fetchModels(makeSelect.value, yearSelect.value);
        updateURL();
        if(productInfo){
          productInfo.classList.remove('noProductFound')
        }
    });

    // Event listener for changes in the "Model" dropdown
    modelSelect && modelSelect.addEventListener('change', () => {
        if (productInfo) { productInfo.innerHTML = '' };
        engineTypeSelect.value = '';
        engineTypeSelect.nextElementSibling.classList.remove('hidden')
        fetchEngineTypes(makeSelect.value, yearSelect.value, modelSelect.value );
        updateURL();
        if(productInfo){
          productInfo.classList.remove('noProductFound')
        }
    });

    // Event listener for changes in the "engineType" dropdown
    engineTypeSelect && engineTypeSelect.addEventListener('change', () => {
        if (productInfo) { productInfo.innerHTML = '' };
        // if (window.location.href.includes(pageUrl)) {
        //     fetchSKUs(makeSelect.value, yearSelect.value, modelSelect.value, engineTypeSelect.value);
        // }
        updateURL();
        if(productInfo){
          productInfo.classList.remove('noProductFound')
        }
    });

    // filter reset button
    if (filterResetBtn) {
        filterResetBtn.addEventListener('click', (event) => {
            // Reset select elements
            event.preventDefault();
            makeSelect.innerHTML = '<option value="" selected>Select Make</option>';
            modelSelect.innerHTML = '<option value="" selected>Select Model</option>';
            yearSelect.innerHTML = '<option value="" selected>Select Year</option>';
            engineTypeSelect.innerHTML = '<option value="" selected>Select Engine Type</option>';
            make = '';
            model = '';
            year = '';
            engineType = '';
            if (productInfo) {
                productInfo.innerHTML = '';
                productInfo.classList.remove('noProductFound')
            }
            fetchMakes();
            updateURL();
            $('.filterOptionContent').removeClass('open').slideUp();
            $('.filterOptionContent').html('');
            if(filterChips){
              filterChips.innerHTML = '';
            }
            let filterClass = document.querySelector('.customFilter');
            filterClass.classList.remove('data-in');
            showProducts()
        });
    }

    // widget button
    const form = document.getElementById('ebc-product-search');
    if (form) {
        form.addEventListener('submit', function (event) {
            event.preventDefault();
            const urlParams = new URL(window.location).searchParams;
            const make = urlParams.get("make");
            const model = urlParams.get("model");
            const year = urlParams.get("year");
            const engine_type = urlParams.get("engine_type");
            const baseUrl = pageUrl;
            const queryString = `?make=${encodeURIComponent(make)}&year=${encodeURIComponent(year)}&model=${encodeURIComponent(model)}&engine_type=${encodeURIComponent(engine_type)}`;
            window.location.href = baseUrl + queryString;
        });
    }

    // product card html
    function productCard(sku, product, query, fitmentPosition) {
        let tags = product.tags[0].split(', ')
        let tagInfo = tagColors.filter(item => tags.includes(item.subCategory));
        let badgeColor = '';
        if (tagInfo.length > 0) {
            if (tagInfo[0].labelBg != '#ffffff' && tagInfo[0].labelBg != '#d9d9d9')
                badgeColor = tagInfo[0].labelBg;
        }
        let quantityDropdownValues = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
        let variant = product.variants.find(variant => variant.sku === sku);

        // Define car end images and text based on car_end value
        let carEndImageUrl;
        let carEndText;

        switch (fitmentPosition) {
            case 'Both':
                carEndText = 'Both';
                carEndImageUrl = 'https://www.ebcbrakeshop.co.uk/sites/EBC-Brakes/fitment-Both-axel.svg';
                break;
            case 'Front':
                carEndText = 'Front';
                carEndImageUrl = 'https://www.ebcbrakeshop.co.uk/sites/EBC-Brakes/fitment-Front-axel.svg';
                break;
            case 'Rear':
                carEndText = 'Rear';
                carEndImageUrl = 'https://www.ebcbrakeshop.co.uk/sites/EBC-Brakes/fitment-Rear-axel.svg';
                break;
        }

        // Conditional Stock Info
        let stockInfoHTML = variant.inventory_quantity > 0
            ? `<img style="width:22px;" src="https://cdn.shopify.com/s/files/1/0673/3683/1274/files/check_1_2x_5ccff06c-2027-4340-8ee9-bd795d9091d7.png?v=1730206123">
              <span>${variant.inventory_quantity} In stock</span>`
            : `<img style="width:16px;" src="https://cdn.shopify.com/s/files/1/0673/3683/1274/files/close.png?v=1730206123">
              <span>Out of stock</span>`;

        // Conditional Add-to-Cart Button
        let addToCartButtonHTML = variant.inventory_quantity > 0
            ? `<button onclick="addToCart(${variant.id},event)">ADD TO BASKET</button>`
            : variant.inventory_policy === "deny"
                ? `<button disabled="true">OUT OF STOCK</button>`
                : `<button class="preOrderBtn" onclick="addToCart(${variant.id})">PRE-ORDER</button>`;

        const productHTML = `
           <div class="appProduct">
               <div class="productCardBadgeBox">
                 <p class='carEndBadge'>${carEndText === 'Both' ? 'FRONT & REAR' : carEndText}</p>
                 <p class="colorBadge" style="background-color:${badgeColor};"></p>
               </div>
               <div class="product-sku-img-row">
                   <div class="productImgWrapper">
                     <a href='/products/${product.handle}' target="blank">
                       <img
                           src="${product.image_src}"
                           style="width:100%"
                           class="pFirstImage"
                       >
                       ${product.images[1] ? `<img src="${product.images[1].src}" style="width:100%" class="pSecondImage">` : ''}
                       <img
                           src="${carEndImageUrl}"
                           alt="Both"
                           style="width:86px;"
                           class="car-img"
                       >
                       </a>
                   </div>
                   <a href='/products/${product.handle}' target="blank"><p class="partNo">Part No   <strong>${variant.sku}</strong></p></a>
                   <a href='/products/${product.handle}' target="blank"><p class="partNo"><p class="productTitle">${product.title}</p></a>
                   <p class="productPrice">
                       <span class="defaultPrice">£${variant.price}</span>
                       <span class="comparePrice">${variant.compare_at_price > 0 ? `£${variant.compare_at_price}` : ""}</span>
                       <span class="youSave">
                           ${variant.compare_at_price > variant.price ? `You Save: £${(variant.compare_at_price - variant.price).toFixed(2)}` : ''}
                       </span>
                   </p>
                   <div class="stockInfo">
                       ${stockInfoHTML}
                   </div>
                   <p class="productDetailsHeader">More details</p>
                   <div class="productDetails">
                       <p><span>Make</span><span>${query.make.toUpperCase()}</span></p>
                       <p><span>Model</span><span>${query.model.toUpperCase()}</span></p>
                       <p><span>Engine</span><span>${capitalizeWords(query.engineType)}</span></p>
                       ${query.bhp ? `<p><span>BHP</span><span>${query.bhp}</span></p>` : ''}
                       <p><span>Years</span><span>${query.year}</span></p>
                       ${query.frontBrakeCaliperMake ? `<p><span>Front Caliper</span><span>${query.frontBrakeCaliperMake}</span></p>` : ''}
                       ${query.rearBrakeCaliperMake ? `<p><span>Rear Caliper</span><span>${query.rearBrakeCaliperMake}</span></p>` : ''}
                       ${query.discDiameter ? `<p><span>Disc Diameter</span><span>${query.discDiameter}</span></p>` : ''}
                       ${carEndText ? `<p><span>Fitment Position</span><span>${carEndText}</span></p>` : ''}
                       ${query.included.length > 0 ? `<p><span>Kit Components</span><span>${query.included.join(', ')}</span></p>` : `<p style="height:18.5px;"></p>`}
                   </div>
               </div>
               
               <div class="addToCardWrapper">
                   <select id="quantitySelect_${variant.id}" >
                       ${quantityDropdownValues.map(element => `<option value="${element}">${element}</option>`).join('')}
                   </select>
                   <div style="position:relative;width:100%">
                     ${addToCartButtonHTML}
                     <div class="loading__spinner hidden">
                        <svg xmlns="http://www.w3.org/2000/svg" class="spinner" viewBox="0 0 66 66"><circle stroke-width="6" cx="33" cy="33" r="30" fill="none" class="path"></circle></svg>
                      </div>
                   </div>
               </div>
           </div>`;

        return productHTML;
    }

    // fetch sku and print product cards and run filter logic
    if (window.location.href.includes(pageUrl)) {
        // Function to fetch SKUs based on the selected engine type
        function fetchSKUs(selectedMake, selectedModel, selectedYear, selectedEngineType) {
            // Check if a engine type is selected
            if (selectedEngineType) {
                // Make a request to the backend with the selected engine type value
                fetch(`${serverUrl}/api/csv-data-skus?make=${selectedMake}&model=${selectedModel}&year=${selectedYear}&engine_type=${selectedEngineType}`)
                    .then((response) => response.json())
                    .then((sku) => {
                        let skuArr = [];
                        let filterClass = document.querySelector('.customFilter');
                        filterClass.classList.remove('data-in');
                        filterClass.classList.add('data-in');
                        for (let element of sku) { skuArr.push(element.sku) }
                        // console.log('sku array ', skuArr)
                        domProducts = []
                        // getting product data
                        async function getData(skuArr) {
                            try {
                                const response = await fetch(`${serverUrl}/api/get-products-by-skus`, {
                                    method: "POST",
                                    headers: {
                                        'Content-Type': 'application/json'
                                    },
                                    body: JSON.stringify({
                                        skus: skuArr,
                                        make: selectedMake,
                                        model: selectedModel,
                                        year: selectedYear,
                                        engineType: selectedEngineType
                                    })
                                });
                                const { products, csvDataResults } = await response.json();
                    
                                csvDataResults.forEach((element) => {
                                    let product = products.filter(product => product.variants.some(variant => variant.sku === element.sku));
                                    if (product.length > 0) {
                                        domProducts.push({
                                            query: element,
                                            product: product[0]
                                        })
                                    }
                                })
                                // console.log('domProducts:', domProducts);
                                filterChips.innerHTML = '';
                                productInfo.innerHTML = '';
                                if (domProducts.length > 0) {
                                  const getTagArray = async()=>{
                                    try {
                                      const response = await fetch(`${serverUrl}/api/sorting-tags`,{
                                        method:'GET'
                                      })
                                     const data = await response.json()
                                     const arr = data[0].sortTag.split(',')
                                     return arr;
                                    } catch (error) {
                                      console.log(error)
                                    }
                                  }
                                  const tagPriority = await getTagArray();     
                                  
                                  function containsTag(tags, tagName) {
                                      return tags.some(tag => tag.includes(tagName));
                                  }
                                  if(tagPriority){
                                    domProducts.sort((a, b) => {
                                      // Find the highest-priority tag that each product has
                                      const aPriority = tagPriority.findIndex(tag => containsTag(a.product.tags, tag));
                                      const bPriority = tagPriority.findIndex(tag => containsTag(b.product.tags, tag));
                                  
                                      // If a product doesn't contain any of the priority tags, set its index to a large number to sort it last
                                      const aIndex = aPriority === -1 ? Number.MAX_SAFE_INTEGER : aPriority;
                                      const bIndex = bPriority === -1 ? Number.MAX_SAFE_INTEGER : bPriority;
                                  
                                      // Compare indices to determine sort order
                                      return aIndex - bIndex;
                                    });
                                  }                                 
                                  
                                  domProducts.forEach((element) => {
                                      productInfo.innerHTML += element.product ? productCard(element.query.sku, element.product, element.query, element.query.fitmentPosition) : '';
                                  })
                                  showProducts()

                                } else {
                                    productInfo.classList.add('noProductFound')
                                }

                                filterInitialise(domProducts)
                                moreDetailsAccordian()

                            } catch (error) {
                                console.error('Error fetching products:', error);
                            }
                        }
                        getData(skuArr)
                    })
                    .catch((error) => console.error('Error fetching SKUs:', error));
            }
        }

        let showBtn = document.querySelector('.showBrakes');
        showBtn.addEventListener('click', function () {
            fetchSKUs(makeSelect.value, modelSelect.value, yearSelect.value, engineTypeSelect.value);
        })

        // run the logic when page is refresh with all filter values
        if (make && model && year && engineType) {
            // Assume fetchProductInfo is the function that fetches and displays the product info
            fetchSKUs(make, model, year, engineType);
            // makeSelect.innerHTML = `<option value=${make} selected>${make}</option>`;
            // modelSelect.innerHTML = `<option value=${model} selected>${model}</option>`;
            // yearSelect.innerHTML = `<option value=${year} selected>${year}</option>`;
            // engineTypeSelect.innerHTML = `<option value=${engineType} selected>${engineType}</option>`;
        }

    }

    // filter logic
    function filterInitialise(domProducts) {
        // Open the accordion by default
        $('.filterOptionContent').eq(4).addClass('open').slideDown(100);
        $('.filterOptionContent').eq(5).addClass('open').slideDown(100);
        $('.filterOptionContent').eq(6).addClass('open').slideDown(100);
        $('.filterOptionContent').eq(7).addClass('open').slideDown(100);

        let frontCaliperArr = [], rearCaliperArr = [], fitmentPositionArr = [], tagArr = [], discDiameterArr = [];
        let discDiameterObj = {
            front: [],
            rear: []
        }
        domProducts.forEach((element) => {
            if (element.product) {
                switch (element.query.fitmentPosition.toLowerCase()) {
                    case 'front':
                        element.query.discDiameter != '' ? discDiameterObj.front.push(element.query.discDiameter) : '';
                        break;
                    case 'rear':
                        element.query.discDiameter != '' ? discDiameterObj.rear.push(element.query.discDiameter) : '';
                        break;
                    case 'both':
                        if (element.query.discDiameter != '') {
                            let splitDiameter = element.query.discDiameter.split('/');
                            element.query.discDiameter != '' ? discDiameterObj.front.push(splitDiameter[0]) : '';
                            element.query.discDiameter != '' ? discDiameterObj.rear.push(splitDiameter[1]) : '';
                        }
                        break;
                }
            }
            if (element.product) { element.query.frontBrakeCaliperMake != '' ? frontCaliperArr.push(element.query.frontBrakeCaliperMake) : ''; }
            if (element.product) { element.query.rearBrakeCaliperMake != '' ? rearCaliperArr.push(element.query.rearBrakeCaliperMake) : ''; }
            if (element.product) { element.query.fitmentPosition != '' ? fitmentPositionArr.push(element.query.fitmentPosition) : ''; }
            if (element.product) { element.product.tags != '' ? tagArr.push(...element.product.tags[0].split(', ')) : ''; }
        })
        let filterValues = {
            discDiameter: {
                front: new Set(discDiameterObj.front),
                rear: new Set(discDiameterObj.rear)
            },
            frontCaliper: new Set(frontCaliperArr),
            rearCaliper: new Set(rearCaliperArr),
            positionFitment: new Set(fitmentPositionArr),
            tagArr: new Set(tagArr)
        }

        let frontDiscDiameterWrapper = document.querySelector('.front_disc_diameter');
        let frontCaliperWrapper = document.querySelector('.front_caliper');
        let rearDiscDiameterWrapper = document.querySelector('.rear_disc_diameter');
        let rearCaliperWrapper = document.querySelector('.rear_caliper');
        let positionFitmentWrapper = document.querySelector('.position_fitment');

        let compoundWrapper = document.querySelector('.Compound');
        let discTypeWrapper = document.querySelector('.Disc_Type');
        let productTypeWrapper = document.querySelector('.Product_Type');
        let accessoriesWrapper = document.querySelector('.Accessories');

        $('.filterOptionContent').html('');

        // create options
        for (let property in filterValues) {
            switch (property) {
                case 'discDiameter':
                    filterValues[property].front.forEach((option) => {
                        frontDiscDiameterWrapper.innerHTML += `<li><input type='checkbox' value=${option}>${option}</li>`;
                    })
                    filterValues[property].rear.forEach((option) => {
                        rearDiscDiameterWrapper.innerHTML += `<li><input type='checkbox' value=${option}>${option}</li>`;
                    })
                    break;
                case 'frontCaliper':
                    filterValues[property].forEach((option) => {
                        frontCaliperWrapper.innerHTML += `<li><input type='checkbox' value=${option}>${option}</li>`;
                    })
                    break;
                case 'rearCaliper':
                    filterValues[property].forEach((option) => {
                        rearCaliperWrapper.innerHTML += `<li><input type='checkbox' value=${option}>${option}</li>`;
                    })
                    break;
                case 'positionFitment':

                    const desiredOrder = ['Front', 'Rear', 'Both'];
                    filterValues[property] = desiredOrder.filter(item => filterValues[property].has(item));
                    filterValues[property].forEach((option) => {
                        if (option === 'Rear') {
                            positionFitmentWrapper.innerHTML += "<li class='flex py-1' style='justify-content:space-between;'><div><input type='checkbox' value='Rear'>Rear </div><img class='ml-6 w-[60px]' src='https://www.ebcbrakeshop.co.uk/sites/EBC-Brakes/fitment-Rear-axel.svg'></li>";
                        } else if (option === 'Front') {
                            positionFitmentWrapper.innerHTML += "<li class='flex py-1' style='justify-content:space-between;'><div><input type='checkbox' value='Front'>Front </div><img class='ml-4 w-[60px]' src='https://www.ebcbrakeshop.co.uk/sites/EBC-Brakes/fitment-Front-axel.svg'></li>";
                        } else if (option === 'Both') {
                            positionFitmentWrapper.innerHTML += "<li class='flex py-1' style='justify-content:space-between;'><div><input type='checkbox' value='Both'>Both </div><img class='ml-5 w-[60px]' src='https://www.ebcbrakeshop.co.uk/sites/EBC-Brakes/fitment-Both-axel.svg'></li>";
                        }
                    })
                    break;
            }
        }

        // create options
        for (let item of filterQueryData) {
            if (item.name == 'Compound') {
                item.options.forEach((option) => {
                    if (filterValues.tagArr.has(option.subCategory)) {
                        compoundWrapper.innerHTML += `<li class="flex py-2" style="justify-content:space-between;">
                                       <div>
                                         <input type="checkbox" value="${option.subCategory}">
                                         ${option.subCategory}
                                       </div>
                                       ${option.labelImage ? `<img src="${serverUrl}${option.labelImage}" style="height:20px;">` : option.labelText && option.labelImage == null ? `<span class="labelBox" style="background-color:${option.labelBg}">${option.labelText}</span>` : `<span class="labelBox" style="background-color:${option.labelBg}"></span>`}
                                    </li>`
                    }
                })
            } else if (item.name == 'Disc Type') {
                item.options.forEach((option) => {
                    if (filterValues.tagArr.has(option.subCategory)) {
                        discTypeWrapper.innerHTML += `<li class="flex py-2" style="justify-content:space-between;">
                                       <div>
                                         <input type="checkbox" value="${option.subCategory}">
                                         ${option.subCategory}
                                       </div>
                                       ${option.labelImage ? `<img src="${serverUrl}${option.labelImage}" style="height:20px;">` : option.labelText && option.labelImage == null ? `<span class="labelBox" style="background-color:${option.labelBg}">${option.labelText}</span>` : `<span class="labelBox" style="background-color:${option.labelBg}"></span>`}
                                    </li>`
                    }
                })
            } else if (item.name == 'Product Type') {
                item.options.forEach((option) => {
                    if (filterValues.tagArr.has(option.subCategory)) {
                        productTypeWrapper.innerHTML += `<li class="flex py-2" style="justify-content:space-between;">
                                       <div>
                                         <input type="checkbox" value="${option.subCategory}">
                                         ${option.subCategory}
                                       </div>
                                       ${option.labelImage ? `<img src="${serverUrl}${option.labelImage}" style="height:20px;">` : option.labelText && option.labelImage == null ? `<span class="labelBox" style="background-color:${option.labelBg}">${option.labelText}</span>` : `<span class="labelBox" style="background-color:${option.labelBg}"></span>`}
                                    </li>`
                    }
                })
            } else if (item.name == 'Accessories') {
                item.options.forEach((option) => {
                    if (filterValues.tagArr.has(option.subCategory)) {
                        accessoriesWrapper.innerHTML += `<li class="flex py-2" style="justify-content:space-between;">
                                       <div>
                                         <input type="checkbox" value="${option.subCategory}">
                                         ${option.subCategory}
                                       </div>
                                       ${option.labelImage ? `<img src="${serverUrl}${option.labelImage}" style="height:20px;">` : option.labelText && option.labelImage == null ? `<span class="labelBox" style="background-color:${option.labelBg}">${option.labelText}</span>` : `<span class="labelBox" style="background-color:${option.labelBg}"></span>`}
                                    </li>`
                    }
                })
            }
        }

        let frontDiscDiameterCondition = [];
        let frontCaliperCondition = [];
        let rearDiscDiameterCondition = [];
        let rearCaliperCondition = [];
        let positionFitmentCondition = [];

        let productTypeCondition = [];
        let compoundCondition = [];
        let disTypeCondition = [];
        let accessoriesCondition = [];

        const allFilterInputs = document.querySelectorAll('.filterOptionContent input');

        function updateFilterConditions(array, value, add) {
            if (add) {
                if (!array.includes(value)) {
                    array.push(value);
                }
            } else {
                // Remove the value using filter to avoid using pop incorrectly
                array = array.filter(item => item !== value);
            }
            return array; // Return the updated array
        }

        // filter checkbox onclick function
        allFilterInputs.forEach((inputBox) => {
            inputBox.addEventListener('change', function (event) {
                if (this.parentElement.parentElement.classList.contains('front_disc_diameter')) {
                    frontDiscDiameterCondition = updateFilterConditions(frontDiscDiameterCondition, event.target.value, event.target.checked);
                } else if (this.parentElement.parentElement.classList.contains('front_caliper')) {
                    frontCaliperCondition = updateFilterConditions(frontCaliperCondition, event.target.value, event.target.checked);
                } else if (this.parentElement.parentElement.classList.contains('rear_disc_diameter')) {
                    rearDiscDiameterCondition = updateFilterConditions(rearDiscDiameterCondition, event.target.value, event.target.checked);
                } else if (this.parentElement.parentElement.classList.contains('rear_caliper')) {
                    rearCaliperCondition = updateFilterConditions(rearCaliperCondition, event.target.value, event.target.checked);
                } else if (this.parentElement.parentElement.parentElement.classList.contains('position_fitment')) {
                    positionFitmentCondition = updateFilterConditions(positionFitmentCondition, event.target.value, event.target.checked);

                } else if (this.parentElement.parentElement.parentElement.classList.contains('Product_Type')) {
                    productTypeCondition = updateFilterConditions(productTypeCondition, event.target.value, event.target.checked);
                } else if (this.parentElement.parentElement.parentElement.classList.contains('Compound')) {
                    compoundCondition = updateFilterConditions(compoundCondition, event.target.value, event.target.checked);
                } else if (this.parentElement.parentElement.parentElement.classList.contains('Disc_Type')) {
                    disTypeCondition = updateFilterConditions(disTypeCondition, event.target.value, event.target.checked);
                } else if (this.parentElement.parentElement.parentElement.classList.contains('Accessories')) {
                    accessoriesCondition = updateFilterConditions(accessoriesCondition, event.target.value, event.target.checked);
                }
                let filteredResults = domProducts.filter(product => {
                    const productValues = Object.values(product.query); // Assuming your structure
                    const tags = product && product.product && typeof product.product.tags !== 'undefined' ? product.product.tags[0].split(', ') : '';

                    function flattenArray(data) {
                        return data.reduce((acc, val) => Array.isArray(val) ? acc.concat(flattenArray(val)) : acc.concat(val.toString()), []);
                    }
                    const flattenedArr = flattenArray(productValues);
                    // Check conditions with AND between groups, OR within each group
                    const meetsCondition1 = frontDiscDiameterCondition.length === 0 || frontDiscDiameterCondition.some(s => flattenedArr.some(item => item.includes(s)));
                    const meetsCondition2 = frontCaliperCondition.length === 0 || frontCaliperCondition.some(condition => productValues.includes(condition));
                    const meetsCondition3 = rearDiscDiameterCondition.length === 0 || rearDiscDiameterCondition.some(s => flattenedArr.some(item => item.includes(s)));
                    const meetsCondition4 = rearCaliperCondition.length === 0 || rearCaliperCondition.some(condition => productValues.includes(condition));
                    const meetsCondition5 = positionFitmentCondition.length === 0 || positionFitmentCondition.some(condition => productValues.includes(condition));

                    const meetsCondition6 = productTypeCondition.length === 0 || productTypeCondition.some(condition => tags.includes(condition));
                    const meetsCondition7 = compoundCondition.length === 0 || compoundCondition.some(condition => tags.includes(condition));
                    const meetsCondition8 = disTypeCondition.length === 0 || disTypeCondition.some(condition => tags.includes(condition));
                    const meetsCondition9 = accessoriesCondition.length === 0 || accessoriesCondition.some(condition => tags.includes(condition));
                    return meetsCondition1 && meetsCondition2 && meetsCondition3 && meetsCondition4 && meetsCondition5 && meetsCondition6 && meetsCondition7 && meetsCondition8 && meetsCondition9;
                });
                // console.log(filteredResults);
                let c = frontDiscDiameterCondition.length + frontCaliperCondition.length + rearDiscDiameterCondition.length + rearCaliperCondition.length + positionFitmentCondition.length + productTypeCondition.length + compoundCondition.length + disTypeCondition.length + accessoriesCondition.length;
                if (filteredResults.length > 0) {
                    productInfo.innerHTML = ''
                    productInfo.classList.remove('noProductFound')
                    filteredResults.forEach((element) => {
                        productInfo.innerHTML += element.product ? productCard(element.query.sku, element.product, element.query, element.query.fitmentPosition) : '';
                    })
                    currentPage = 1;
                    showProducts()

                } else if (filteredResults.length == 0 && c != 0) {
                    productInfo.innerHTML = '';
                    productInfo.classList.add('noProductFound');
                    currentPage = 1;
                    showProducts()
                } else {
                    productInfo.innerHTML = '';
                    productInfo.classList.remove('noProductFound');
                    domProducts.forEach((element) => {
                        productInfo.innerHTML += element.product ? productCard(element.query.sku, element.product, element.query, element.query.fitmentPosition) : '';
                    })
                    currentPage = 1;
                    showProducts()

                }
                $('.customFilter').removeClass('open');
            })
        })
    }

    // fetch tag filter headers and content wrapper from app
    const fetchfilter = async (afterSearch) => {
        const filter = document.querySelector('.tagFilterWrapper');
        if (filter) {
            filter.innerHTML = '';
            let str = '';

            fetch(`${serverUrl}/api/get-category`)
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Network response was not ok');
                    }
                    return response.json();
                })
                .then(data => {
                    filterQueryData = data;
                    let specificTag = filterQueryData.filter(item => item.name == 'Compound');
                    tagColors = specificTag[0].options;

                    filterQueryData.forEach(element => {
                        if (afterSearch) {
                            str += `<div class="filterSelect">
                               <p class="filterOptionHeader">${element.name}</p>
                               <ul class="filterOptionContent ${element.name.replace(' ', '_')}">
                                 ${element.options.map(option => (
                                `<li class="flex py-2" style="justify-content:space-between;">
                                       <div>
                                         <input type="checkbox" value="${option.subCategory}">
                                         ${option.subCategory}
                                       </div>
                                       ${option.labelImage ? `<img src="${serverUrl}${option.labelImage}" style="height:20px;">` : option.labelText && option.labelImage == null ? `<span class="labelBox" style="background-color:${option.labelBg}">${option.labelText}</span>` : `<span class="labelBox" style="background-color:${option.labelBg}"></span>`}
                                    </li>`
                            )
                            ).join('')}
                               </ul>
                           </div>`;
                        } else {
                            str += `<div class="filterSelect">
                               <p class="filterOptionHeader">${element.name}</p>
                               <ul class="filterOptionContent ${element.name.replace(' ', '_')}"></ul>
                           </div>`;
                        }
                    });
                    filter.innerHTML += str;
                    filterAccordian();

                })
                .catch(error => {
                    console.error('Failed to fetch categories:', error);
                });
        }
    };
    fetchfilter();
});

// filter accordian
function filterAccordian() {

    // Toggle accordion on header click
    $('.filterOptionHeader').click(function () {
        var content = $(this).next('.filterOptionContent');

        // If the clicked section is already open, close it
        if (content.hasClass('open')) {
            content.removeClass('open').slideUp(100);
        } else {

            // Close all open sections
            // $('.filterOptionContent').removeClass('open').slideUp();

            // Open the clicked section
            content.addClass('open').slideDown(100);
        }
    });
};

if ($(window).width() < 900) {

    $('.mainFilterHeader').click(function () {
        const content = $(this).next('.productSearchWrapper');
        if (content.hasClass('open')) {
            content.removeClass('open').slideUp(100);
        } else {
            content.addClass('open').slideDown(100);
        }
    })

    $('.otherFilters').click(function () {
        const content = $('.customFilter')
        if (content.hasClass('open')) {
            content.removeClass('open')
        } else {
            content.addClass('open')
        }
    })

    $('.customFilter > h5').click(function () {
        $('.customFilter').removeClass('open')
    })

}

function moreDetailsAccordian() {
    if ($(window).width() < 900) {
        $('.productDetailsHeader').click(function () {
            const content = $(this).next('.productDetails');
            if (content.hasClass('open')) {
                content.removeClass('open').slideUp(100)
            } else {
                content.addClass('open').slideDown(100)
            }
        })
    }
}

document.addEventListener('change', function (event) {
    // Check if the changed element is one of our quantity selects
    // if (event.target && event.target.matches('select[id^="quantitySelect_"]')) {
    //     const nextSibling = event.target.closest('.addToCardWrapper').querySelector('button a');
    //     if (nextSibling) {
    //         let newQuantity = event.target.value;
    //         let newHref = nextSibling.href.replace(/quantity=\d+/, `quantity=${newQuantity}`);
    //         nextSibling.href = newHref;
    //     }
    // }
    moreDetailsAccordian()
    let arr = [];
    let c = document.querySelectorAll('.customFilter input');
    let currentFilter = document.querySelector('.currentFilter');

    for (let elem of c) {
        if (elem.checked) {
            arr.push(elem.value)
        }
    }
  
    if(currentFilter){
      currentFilter.innerHTML = '';
    }
    
    arr.forEach((element) => {
        currentFilter.innerHTML += `<div>${element}
                                  <span onClick="removefilter(event)"><svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" viewBox="0 0 24 24" fill="none">
                                   <g id="SVGRepo_bgCarrier" stroke-width="0"/>
                                   <g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"/><g id="SVGRepo_iconCarrier"> <rect width="24" height="24" fill="white"/> <path d="M7 17L16.8995 7.10051" stroke="#bfbfbf" stroke-linecap="round" stroke-linejoin="round"/> <path d="M7 7.00001L16.8995 16.8995" stroke="#bfbfbf" stroke-linecap="round" stroke-linejoin="round"/> </g>
                                   </svg>
                                  </span>
                                 </div>`
    })

});

function removefilter(event) {
    let parentDiv = event.target.closest('div');
    let content = parentDiv.childNodes[0].textContent;
    let customFilterArr = document.querySelectorAll('.customFilter input');
    // customFilterArr.forEach(element => console.log(element.value))
    let result = Array.from(customFilterArr).filter((element) => element.value.trim() == content.trim())
    result.forEach(element => {
        element.checked = false;
        element.dispatchEvent(new Event('change'));
    });
    parentDiv.remove();
}


// delivery timer
document.addEventListener('DOMContentLoaded', () => {

    const daysOfWeek = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

    function getOrdinalSuffix(day) {
        if (day > 3 && day < 21) return "th"; // Covers 4th - 20th
        switch (day % 10) {
            case 1: return "st";
            case 2: return "nd";
            case 3: return "rd";
            default: return "th";
        }
    }

    function isHoliday(date) {
        const holidays = []; // Update this list as needed
        const dateString = date.getFullYear() + '-' + ('0' + (date.getMonth() + 1)).slice(-2) + '-' + ('0' + date.getDate()).slice(-2);
        return holidays.includes(dateString);
    }

    function getFixedUKTime() {
        const now = new Date();
        const formatter = new Intl.DateTimeFormat('en-GB', {
            timeZone: 'Europe/London',
            year: 'numeric',
            month: '2-digit',
            day: '2-digit',
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit',
            hour12: false
        });

        // Format the current date as a string in UK timezone
        const ukDateString = formatter.format(now);

        // Convert the string back to a Date object
        const dateParts = ukDateString.match(/(\d{2})\/(\d{2})\/(\d{4}), (\d{2}):(\d{2}):(\d{2})/);
        return new Date(`${dateParts[3]}-${dateParts[2]}-${dateParts[1]}T${dateParts[4]}:${dateParts[5]}:${dateParts[6]}`);
    }

    function getMonthName(date) {
        return new Intl.DateTimeFormat('en-GB', { month: 'short' }).format(date);
    }

    function updateCountdown() {
        var now = getFixedUKTime();
        // var now = new Date('2025-01-12T11:00:00');
        var targetTime = new Date(now.toISOString().split('T')[0]); // Resets to today's date at midnight.
        var deliveryDay; // This will store the date for delivery.
      
        // Handle specific scenarios for extended hours on weekends
        if (now.getDay() === 4 && now.getHours() > 12) { // thrusday after 12 PM
            // Extend to Monday 12 PM
            targetTime.setDate(now.getDate() + 3);
            targetTime.setHours(12, 0, 0, 0);
            deliveryDay = new Date(targetTime.getTime());
            deliveryDay.setDate(deliveryDay.getDate()); 
          
        } else if (now.getDay() === 5) { // Friday after 12 PM
            // Extend to Monday 12 PM
            targetTime.setDate(now.getDate() + 2);
            targetTime.setHours(12, 0, 0, 0);
            deliveryDay = new Date(targetTime.getTime());
            deliveryDay.setDate(deliveryDay.getDate()); 
          
        } else if (now.getDay() === 6) { // Saturday
            // Extend to Monday 12 PM
            targetTime.setDate(now.getDate() + 1);
            targetTime.setHours(12, 0, 0, 0);
            deliveryDay = new Date(targetTime.getTime());
            deliveryDay.setDate(deliveryDay.getDate()); 
          
        } else {
            if (now.getHours() < 12) {
                // If it's before 12 PM, countdown to today's 12 PM, delivery tomorrow.
                targetTime.setHours(12, 0, 0, 0); // Set target time to today's noon.
                deliveryDay = new Date(targetTime.getTime());
                deliveryDay.setDate(deliveryDay.getDate() + 1); // Delivery tomorrow.
            } else {
                // If it's after 12 PM, countdown to tomorrow's 12 PM, delivery the day after tomorrow.
                targetTime.setDate(targetTime.getDate() + 1); // Move to tomorrow.
                targetTime.setHours(12, 0, 0, 0); // Set target time to noon.
                deliveryDay = new Date(targetTime.getTime());
                deliveryDay.setDate(deliveryDay.getDate() + 1); // Delivery the day after tomorrow.
            }
        }

        // Avoid Sundays and holidays for the delivery day
        while (deliveryDay.getDay() === 0 || isHoliday(deliveryDay)) {
            if(isHoliday(deliveryDay)){
                targetTime.setDate(targetTime.getDate() + 1); 
            }
            deliveryDay.setDate(deliveryDay.getDate() + 1); // Move to the next day if Sunday or a holiday.
        }

        // Formatting the dispatch date for display
        var dispatchText = document.querySelectorAll('.dispatch-text');
        var dayName = daysOfWeek[deliveryDay.getDay()];
        var dateWithSuffix = deliveryDay.getDate() + getOrdinalSuffix(deliveryDay.getDate());
        var monthName = getMonthName(deliveryDay);
        dispatchText.forEach((element) => {
            element.innerHTML = `for delivery ${dayName} ${dateWithSuffix} ${monthName}`;
        })

        // Calculate the time difference and update the countdown
        var timeDifference = targetTime - now;
// console.log('now',now)
// console.log('targetTime',targetTime)
// console.log('timeDifference',timeDifference)
        if (timeDifference > 0) {
            var hours = Math.floor(timeDifference / 3600000);
            var minutes = Math.floor((timeDifference % 3600000) / 60000);
            var seconds = Math.floor((timeDifference % 60000) / 1000);
            let countdownTimer = document.querySelectorAll('.countdown-timer');
            countdownTimer.forEach((element) => {
                element.innerHTML = `${hours}h ${minutes}m ${seconds}s`;
            })
        }else{
           var hours = Math.floor(timeDifference / 3600000);
            var minutes = Math.floor((timeDifference % 3600000) / 60000);
            var seconds = Math.floor((timeDifference % 60000) / 1000);
            let countdownTimer = document.querySelectorAll('.countdown-timer');
            countdownTimer.forEach((element) => {
                element.innerHTML = `${hours}h ${minutes}m ${seconds}s`;
            })
        }
    }

    setInterval(updateCountdown, 1000);
    updateCountdown(); // Initial call to start the countdown

})

// ebc search page pagination 
const productsPerPage = 45;
let currentPage = 1;

function showProducts() {
    const products = document.querySelectorAll('#appProductWrapper .appProduct');
    const totalProducts = products.length;
    const totalPages = Math.ceil(totalProducts / productsPerPage);

    // Calculate the range of products to display
    const start = (currentPage - 1) * productsPerPage;
    const end = start + productsPerPage;
    products.forEach((product, index) => {
        product.style.display = (index >= start && index < end) ? 'block' : 'none';
    });

    updatePaginationDisplay(totalPages, totalProducts);
}

function updatePaginationDisplay(totalPages, totalProducts) {
    const paginationLinks = document.getElementById('paginationLinks');
    paginationLinks.innerHTML = ''; // Clear existing links

    // Define the range for the first pages and the last pages
    let startPages = 1;
    let endPages = totalPages;
    let showStartEllipsis = false;
    let showEndEllipsis = false;

    if (totalPages > 6) {
        // More complex pagination scenario
        if (currentPage > 4) {
            showStartEllipsis = true;
            startPages = Math.min(currentPage - 1, totalPages - 5);
        }

        if (currentPage < totalPages - 3) {
            showEndEllipsis = true;
            endPages = Math.max(currentPage + 1, 6);
        }
    }

    // Always show the first three pages
    for (let i = 1; i <= Math.min(3, totalPages); i++) {
        if (i < startPages) {
            paginationLinks.appendChild(createPageLink(i));
        }
    }

    // Show ellipses if necessary before middle pages
    if (showStartEllipsis) {
        paginationLinks.appendChild(createEllipses());
    }

    // Display middle pages if necessary
    for (let i = startPages; i <= endPages; i++) {
        paginationLinks.appendChild(createPageLink(i));
    }

    // Show ellipses if necessary before the last pages
    if (showEndEllipsis) {
        paginationLinks.appendChild(createEllipses());
    }

    // Always show the last three pages
    for (let i = Math.max(totalPages - 2, endPages + 1); i <= totalPages; i++) {
        paginationLinks.appendChild(createPageLink(i));
    }

    document.getElementById('productCount').textContent = `Showing ${Math.min(productsPerPage, totalProducts - (currentPage - 1) * productsPerPage)} of ${totalProducts} products`;
}

function createPageLink(page) {
    const link = document.createElement('button');
    link.textContent = page;
    link.onclick = function() { goToPage(page); };
    if (page === currentPage) {
        link.classList.add('currentPage')
    }
    return link;
}

function createEllipses() {
    const span = document.createElement('span');
    span.textContent = '...';
    return span;
}

function goToPage(pageNumber) {
    currentPage = pageNumber;
    showProducts();
}

function changePage(step) {
    const totalProducts = document.querySelectorAll('#appProductWrapper .appProduct').length;
    const totalPages = Math.ceil(totalProducts / productsPerPage);
    currentPage += step;

    // Boundary check for pagination
    if (currentPage < 1) currentPage = 1;
    else if (currentPage > totalPages) currentPage = totalPages;

    showProducts();
}

// Event listeners for pagination buttons
let prevPage = document.getElementById('prevPage')
if(prevPage){prevPage.addEventListener('click', () => changePage(-1));}
let nextPage = document.getElementById('nextPage')
if(nextPage){nextPage.addEventListener('click', () => changePage(1));}

//-------- add to cart--------------//
function addToCart(variantId,event) {
  event.target.disabled = true;
  event.target.classList.add('loadingCart');
  event.target.nextElementSibling.classList.remove('hidden');
  let select = document.querySelector(`#quantitySelect_${variantId}`)
  let quantity = select.value;
    fetch(`/cart/add.js`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            id: variantId,
            quantity: quantity
        })
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.json();  // This parses the JSON body of the response
    })
    .then(data => {

        updateCartBubble()
        // popup logic while click on collection page add-to-cart button.
        // updateCartNotification(data.key)

        // drawer logic while click on collection page add-to-cart button.
        updateCartDrawer()
      
        event.target.disabled = false;
        event.target.classList.remove('loadingCart');
        event.target.nextElementSibling.classList.add('hidden');
        
    })
    .catch(error => {
        console.error('Error adding item to cart:', error.message);
    });
}

function updateCartBubble() {
  fetch(`/?section_id=cart-icon-bubble`)
    .then(response => response.text())
    .then(html => {
      const parser = new DOMParser();
      const doc = parser.parseFromString(html, "text/html");
      const newCartBubbleContent = doc.querySelector('.shopify-section').innerHTML;
      document.querySelector('#cart-icon-bubble').innerHTML = newCartBubbleContent;
    })
    .catch(err => console.error('Failed to update cart bubble:', err));
}

function escapeCSS(id) {
    return id.replace(/([^\w-])/g, '\\$1');
}

function updateCartNotification(addedProductKey) {
  fetch(`/cart?sections=cart-notification-product`)
    .then(response => response.text())
    .then(text => {
      const json = JSON.parse(text);
      const html = json['cart-notification-product'];
      const parser = new DOMParser();
      const doc = parser.parseFromString(html, "text/html");
      const escapedId = escapeCSS(`cart-notification-product-${addedProductKey}`);
      const newCartContent = doc.querySelector(`#${escapedId}`);
      if (newCartContent) {
        document.querySelector('#cart-notification-product').innerHTML = newCartContent.innerHTML;
        showCartNotification();
      }
    })
    .catch(error => console.error('Error updating cart notification product:', error));

    fetch(`/cart?sections=cart-notification-button`)
    .then(response => response.text())
    .then(text => {
      const json = JSON.parse(text);
      const html = json['cart-notification-button'];
      const parser = new DOMParser();
      const doc = parser.parseFromString(html, "text/html");
      const newCartContent = doc.querySelector(`.shopify-section`);
      if (newCartContent) {
        document.querySelector('#cart-notification-button').innerHTML = newCartContent.innerHTML;
      }
    })
    .catch(error => console.error('Error updating cart notification button:', error));
}

function showCartNotification() {
  const notification = document.querySelector('cart-notification');
  if (notification) {
    notification.open();
  }
}

const updateCartDrawer = async()=>{
  await updateDrawer()
  openDrawer()
}

const updateDrawer = async()=>{
  fetch(`/cart?sections=cart-drawer`)
    .then(response => response.text())
    .then(text => {
      const json = JSON.parse(text);
      const html = json['cart-drawer'];
      const parser = new DOMParser();
      const doc = parser.parseFromString(html, "text/html");
      const newCartDrawerContent = doc.querySelector('cart-drawer').innerHTML;
      document.querySelector('cart-drawer').innerHTML = newCartDrawerContent;
      document.querySelector('cart-drawer').classList.remove('is-empty')
    })
    .catch(err => console.error('Failed to update cart drawer:', err));
}

const openDrawer = ()=>{
  const drawer = document.querySelector('cart-drawer');
  drawer && drawer.open();
}